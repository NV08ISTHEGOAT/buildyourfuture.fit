BUILD YOUR FUTURE INSTALLER (Windows)
=====================================

What it does
- Installs the Build Your Future app on your iPhone over USB, and keeps it working:
  free Apple IDs need a refresh every 7 days. Plug in your iPhone and it refreshes
  by itself (and installs the newest version from buildyourfuture.fit).
- No Sideloadly needed.

How to use
1. Unzip this folder somewhere you keep programs (for example Documents\Build Your Future Installer).
2. Open "Build Your Future Installer.exe".
3. Log in with your Apple ID once (inside the app). Apple may send a code to your iPhone or Mac.
4. Plug in your iPhone with a cable, unlock it, tap Trust if it asks.
5. Press Refresh now. On the iPhone, the first time:
   - Settings > Privacy & Security > Developer Mode > On (then restart),
   - Settings > General > VPN & Device Management > your Apple ID > Trust.

Needs
- Windows 10 or 11.
- iTunes or the Apple Devices app installed (Windows needs their USB driver to talk to an iPhone).

Your Apple ID
- It is only used to sign and install Build Your Future on your own iPhone, the same way Sideloadly
  and AltStore do it with a free Apple ID (Apple calls this a "Personal Team").
- It goes from this PC straight to Apple. It is never sent to Build Your Future. The login is saved
  only on this PC (by the engine, in %APPDATA%\PlumeImpactor).
- Apple's own page about free Apple IDs and on-device testing:
  https://developer.apple.com/support/compare-memberships/

What's inside
- Build Your Future Installer.exe   the app (source code: https://buildyourfuture.fit/installer-source/)
- engine\plumesign.exe              the signing engine from the open-source Impactor project (MIT license,
                                    https://github.com/claration/impactor), unchanged
- engine\LICENSE-Impactor.txt       its license

Windows may say "Windows protected your PC" the first time, because the app is new and not yet
code-signed with a paid certificate. That is normal for small free tools. Click "More info" to see
the publisher and file name before you decide to run it.

License
- (c) 2026 Build Your Future. All rights reserved. Using this installer means you agree to the EULA:
  https://buildyourfuture.fit/eula.html  (privacy: https://buildyourfuture.fit/privacy.html)
